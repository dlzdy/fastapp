package io.dcloud.common.util;

/** @deprecated */
public abstract interface CustomPath
{
  public static final String CUSTOM_PATH_CONTROL_XML = "control_xml_path";
  public static final String CUSTOM_PATH_FS_ROOT = "fs_root_path";
  public static final String CUSTOM_PATH_DOWNLOADS = "downloads";
  public static final String CUSTOM_PATH_DOCUMENTS = "documents";
  public static final String CUSTOM_PATH_APPS = "runtime_apps";
  public static final String CUSTOM_PATH_APP_WWW = "www";
  public static final String CUSTOM_PATH_DOC = "doc";
}

/* Location:           F:\xunlei\sdk\Android-SDK@1.9.9.29448_20170217\Android-SDK\SDK\libs\pdr.jar
 * Qualified Name:     io.dcloud.common.util.CustomPath
 * JD-Core Version:    0.6.2
 */