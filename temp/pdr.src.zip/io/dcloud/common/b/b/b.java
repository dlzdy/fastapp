/*   */ package io.dcloud.common.b.b;
/*   */ 
/*   */ import io.dcloud.common.adapter.ui.AdaFrameItem;
/*   */ 
/*   */ final class b
/*   */ {
/*   */   public static void a(int paramInt, AdaFrameItem[] paramArrayOfAdaFrameItem)
/*   */   {
/* 8 */     if (paramArrayOfAdaFrameItem != null)
/*   */     {
/* 14 */       for (AdaFrameItem localAdaFrameItem : paramArrayOfAdaFrameItem)
/* 15 */         if (localAdaFrameItem != null)
/* 16 */           localAdaFrameItem.startAnimator(paramInt);
/*   */     }
/*   */   }
/*   */ }

/* Location:           F:\xunlei\sdk\Android-SDK@1.9.9.29448_20170217\Android-SDK\SDK\libs\pdr.jar
 * Qualified Name:     io.dcloud.common.b.b.b
 * JD-Core Version:    0.6.2
 */