/*    */ package io.dcloud.common.a;
/*    */ 
/*    */ class f
/*    */ {
/*  5 */   boolean a = false;
/*    */   String b;
/*  9 */   boolean c = false;
/* 10 */   boolean d = false;
/*    */ 
/* 12 */   public void a() { this.a = false;
/* 13 */     this.b = null;
/* 14 */     this.c = false;
/* 15 */     this.d = false;
/*    */   }
/*    */ }

/* Location:           F:\xunlei\sdk\Android-SDK@1.9.9.29448_20170217\Android-SDK\SDK\libs\pdr.jar
 * Qualified Name:     io.dcloud.common.a.f
 * JD-Core Version:    0.6.2
 */