package io.dcloud.common.DHInterface;

import android.content.Context;

public abstract interface IOnCreateSplashView
{
  public abstract Object onCreateSplash(Context paramContext);

  public abstract void onCloseSplash();
}

/* Location:           F:\xunlei\sdk\Android-SDK@1.9.9.29448_20170217\Android-SDK\SDK\libs\pdr.jar
 * Qualified Name:     io.dcloud.common.DHInterface.IOnCreateSplashView
 * JD-Core Version:    0.6.2
 */