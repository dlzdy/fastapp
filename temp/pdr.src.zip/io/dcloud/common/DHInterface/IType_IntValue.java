package io.dcloud.common.DHInterface;

abstract interface IType_IntValue
{
  public static final int SCREEN_WIDTH = 0;
  public static final int SCREEN_HEIGHT = 1;
  public static final int SCREEN_ALL_HEIGHT = 2;

  public abstract int getInt(int paramInt);
}

/* Location:           F:\xunlei\sdk\Android-SDK@1.9.9.29448_20170217\Android-SDK\SDK\libs\pdr.jar
 * Qualified Name:     io.dcloud.common.DHInterface.IType_IntValue
 * JD-Core Version:    0.6.2
 */