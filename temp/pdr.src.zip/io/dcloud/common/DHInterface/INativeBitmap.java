package io.dcloud.common.DHInterface;

import android.graphics.Bitmap;

public abstract interface INativeBitmap
{
  public abstract void clear();

  public abstract Bitmap getBitmap();

  public abstract void setBitmap(Bitmap paramBitmap);
}

/* Location:           F:\xunlei\sdk\Android-SDK@1.9.9.29448_20170217\Android-SDK\SDK\libs\pdr.jar
 * Qualified Name:     io.dcloud.common.DHInterface.INativeBitmap
 * JD-Core Version:    0.6.2
 */