package io.dcloud.common.DHInterface;

abstract interface IType_Layout_Changed
{
  public static final int INIT_CHANGED = 0;
  public static final int ORIENTATION_CHANGED = 1;
  public static final int SCREEN_CHANGED_TO_FULL = 2;
  public static final int GLOBAL_LAYOUT_CHANGED = 3;
}

/* Location:           F:\xunlei\sdk\Android-SDK@1.9.9.29448_20170217\Android-SDK\SDK\libs\pdr.jar
 * Qualified Name:     io.dcloud.common.DHInterface.IType_Layout_Changed
 * JD-Core Version:    0.6.2
 */