package io.dcloud.common.DHInterface;

public abstract interface ITypeofAble
{
}

/* Location:           F:\xunlei\sdk\Android-SDK@1.9.9.29448_20170217\Android-SDK\SDK\libs\pdr.jar
 * Qualified Name:     io.dcloud.common.DHInterface.ITypeofAble
 * JD-Core Version:    0.6.2
 */