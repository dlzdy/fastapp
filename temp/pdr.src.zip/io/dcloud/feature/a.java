/*    */ package io.dcloud.feature;
/*    */ 
/*    */ import io.dcloud.common.DHInterface.AbsMgr;
/*    */ import io.dcloud.common.DHInterface.IBoot;
/*    */ import io.dcloud.common.DHInterface.IFeature;
/*    */ 
/*    */ public class a
/*    */ {
/*    */   public static IBoot a(AbsMgr paramAbsMgr, String paramString)
/*    */   {
/* 26 */     return null;
/*    */   }
/*    */ 
/*    */   public static IFeature b(AbsMgr paramAbsMgr, String paramString)
/*    */   {
/* 69 */     return null;
/*    */   }
/*    */ }

/* Location:           F:\xunlei\sdk\Android-SDK@1.9.9.29448_20170217\Android-SDK\SDK\libs\pdr.jar
 * Qualified Name:     io.dcloud.feature.a
 * JD-Core Version:    0.6.2
 */