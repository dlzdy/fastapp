package io.dcloud.feature.internal.reflect;

import android.content.Context;
import android.content.Intent;

public abstract interface BroadcastReceiver
{
  public abstract void onReceive(Context paramContext, Intent paramIntent);
}

/* Location:           F:\xunlei\sdk\Android-SDK@1.9.9.29448_20170217\Android-SDK\SDK\libs\pdr.jar
 * Qualified Name:     io.dcloud.feature.internal.reflect.BroadcastReceiver
 * JD-Core Version:    0.6.2
 */