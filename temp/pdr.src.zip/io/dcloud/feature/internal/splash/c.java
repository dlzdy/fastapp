package io.dcloud.feature.internal.splash;

import android.graphics.Bitmap;

public abstract interface c
{
  public abstract void a(String paramString);

  public abstract void a(Bitmap paramBitmap);
}

/* Location:           F:\xunlei\sdk\Android-SDK@1.9.9.29448_20170217\Android-SDK\SDK\libs\pdr.jar
 * Qualified Name:     io.dcloud.feature.internal.splash.c
 * JD-Core Version:    0.6.2
 */