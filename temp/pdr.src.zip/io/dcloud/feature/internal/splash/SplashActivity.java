package io.dcloud.feature.internal.splash;

import android.app.Activity;

public class SplashActivity extends Activity
{
}

/* Location:           F:\xunlei\sdk\Android-SDK@1.9.9.29448_20170217\Android-SDK\SDK\libs\pdr.jar
 * Qualified Name:     io.dcloud.feature.internal.splash.SplashActivity
 * JD-Core Version:    0.6.2
 */