package io.dcloud.feature;

import android.app.Activity;
import io.dcloud.common.DHInterface.IReflectAble;
import java.util.HashMap;

abstract interface c extends IReflectAble
{
  public abstract HashMap a();

  public abstract Object a(String paramString, Activity paramActivity);

  public abstract Object a(String paramString);
}

/* Location:           F:\xunlei\sdk\Android-SDK@1.9.9.29448_20170217\Android-SDK\SDK\libs\pdr.jar
 * Qualified Name:     io.dcloud.feature.c
 * JD-Core Version:    0.6.2
 */