package io.dcloud;

import android.view.KeyEvent;
import io.dcloud.common.DHInterface.ISysEventListener.SysEventType;

public abstract interface d
{
  public abstract boolean onKeyEventExecute(ISysEventListener.SysEventType paramSysEventType, int paramInt, KeyEvent paramKeyEvent);
}

/* Location:           F:\xunlei\sdk\Android-SDK@1.9.9.29448_20170217\Android-SDK\SDK\libs\pdr.jar
 * Qualified Name:     io.dcloud.d
 * JD-Core Version:    0.6.2
 */