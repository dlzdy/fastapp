/*    */ package com.dcloud.android.v4.accessibilityservice;
/*    */ 
/*    */ import android.accessibilityservice.AccessibilityServiceInfo;
/*    */ 
/*    */ class AccessibilityServiceInfoCompatJellyBeanMr2
/*    */ {
/*    */   public static int getCapabilities(AccessibilityServiceInfo paramAccessibilityServiceInfo)
/*    */   {
/* 27 */     return paramAccessibilityServiceInfo.getCapabilities();
/*    */   }
/*    */ }

/* Location:           F:\xunlei\sdk\Android-SDK@1.9.9.29448_20170217\Android-SDK\SDK\libs\pdr.jar
 * Qualified Name:     com.dcloud.android.v4.accessibilityservice.AccessibilityServiceInfoCompatJellyBeanMr2
 * JD-Core Version:    0.6.2
 */