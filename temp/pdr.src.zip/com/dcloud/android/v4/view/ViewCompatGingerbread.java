/*    */ package com.dcloud.android.v4.view;
/*    */ 
/*    */ import android.view.View;
/*    */ 
/*    */ class ViewCompatGingerbread
/*    */ {
/*    */   public static int getOverScrollMode(View paramView)
/*    */   {
/* 23 */     return paramView.getOverScrollMode();
/*    */   }
/*    */ 
/*    */   public static void setOverScrollMode(View paramView, int paramInt) {
/* 27 */     paramView.setOverScrollMode(paramInt);
/*    */   }
/*    */ }

/* Location:           F:\xunlei\sdk\Android-SDK@1.9.9.29448_20170217\Android-SDK\SDK\libs\pdr.jar
 * Qualified Name:     com.dcloud.android.v4.view.ViewCompatGingerbread
 * JD-Core Version:    0.6.2
 */