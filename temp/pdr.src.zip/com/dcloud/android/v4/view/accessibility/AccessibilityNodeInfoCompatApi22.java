/*    */ package com.dcloud.android.v4.view.accessibility;
/*    */ 
/*    */ import android.view.View;
/*    */ 
/*    */ class AccessibilityNodeInfoCompatApi22
/*    */ {
/*    */   public static Object getTraversalBefore(Object paramObject)
/*    */   {
/* 27 */     return null;
/*    */   }
/*    */ 
/*    */   public static void setTraversalBefore(Object paramObject, View paramView)
/*    */   {
/*    */   }
/*    */ 
/*    */   public static void setTraversalBefore(Object paramObject, View paramView, int paramInt)
/*    */   {
/*    */   }
/*    */ 
/*    */   public static Object getTraversalAfter(Object paramObject) {
/* 39 */     return null;
/*    */   }
/*    */ 
/*    */   public static void setTraversalAfter(Object paramObject, View paramView)
/*    */   {
/*    */   }
/*    */ 
/*    */   public static void setTraversalAfter(Object paramObject, View paramView, int paramInt)
/*    */   {
/*    */   }
/*    */ }

/* Location:           F:\xunlei\sdk\Android-SDK@1.9.9.29448_20170217\Android-SDK\SDK\libs\pdr.jar
 * Qualified Name:     com.dcloud.android.v4.view.accessibility.AccessibilityNodeInfoCompatApi22
 * JD-Core Version:    0.6.2
 */