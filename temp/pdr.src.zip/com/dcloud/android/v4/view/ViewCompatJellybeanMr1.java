/*    */ package com.dcloud.android.v4.view;
/*    */ 
/*    */ import android.graphics.Paint;
/*    */ import android.view.View;
/*    */ 
/*    */ class ViewCompatJellybeanMr1
/*    */ {
/*    */   public static int getLabelFor(View paramView)
/*    */   {
/* 28 */     return paramView.getLabelFor();
/*    */   }
/*    */ 
/*    */   public static void setLabelFor(View paramView, int paramInt) {
/* 32 */     paramView.setLabelFor(paramInt);
/*    */   }
/*    */ 
/*    */   public static void setLayerPaint(View paramView, Paint paramPaint) {
/* 36 */     paramView.setLayerPaint(paramPaint);
/*    */   }
/*    */ 
/*    */   public static int getLayoutDirection(View paramView) {
/* 40 */     return paramView.getLayoutDirection();
/*    */   }
/*    */ 
/*    */   public static void setLayoutDirection(View paramView, int paramInt) {
/* 44 */     paramView.setLayoutDirection(paramInt);
/*    */   }
/*    */ 
/*    */   public static int getPaddingStart(View paramView) {
/* 48 */     return paramView.getPaddingStart();
/*    */   }
/*    */ 
/*    */   public static int getPaddingEnd(View paramView) {
/* 52 */     return paramView.getPaddingEnd();
/*    */   }
/*    */ 
/*    */   public static void setPaddingRelative(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 56 */     paramView.setPaddingRelative(paramInt1, paramInt2, paramInt3, paramInt4);
/*    */   }
/*    */ 
/*    */   public static int getWindowSystemUiVisibility(View paramView) {
/* 60 */     return paramView.getWindowSystemUiVisibility();
/*    */   }
/*    */ 
/*    */   public static boolean isPaddingRelative(View paramView) {
/* 64 */     return paramView.isPaddingRelative();
/*    */   }
/*    */ }

/* Location:           F:\xunlei\sdk\Android-SDK@1.9.9.29448_20170217\Android-SDK\SDK\libs\pdr.jar
 * Qualified Name:     com.dcloud.android.v4.view.ViewCompatJellybeanMr1
 * JD-Core Version:    0.6.2
 */