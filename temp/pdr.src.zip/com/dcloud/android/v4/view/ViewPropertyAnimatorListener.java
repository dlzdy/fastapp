package com.dcloud.android.v4.view;

import android.view.View;

public abstract interface ViewPropertyAnimatorListener
{
  public abstract void onAnimationStart(View paramView);

  public abstract void onAnimationEnd(View paramView);

  public abstract void onAnimationCancel(View paramView);
}

/* Location:           F:\xunlei\sdk\Android-SDK@1.9.9.29448_20170217\Android-SDK\SDK\libs\pdr.jar
 * Qualified Name:     com.dcloud.android.v4.view.ViewPropertyAnimatorListener
 * JD-Core Version:    0.6.2
 */