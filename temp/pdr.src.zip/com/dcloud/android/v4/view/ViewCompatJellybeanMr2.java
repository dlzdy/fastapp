/*    */ package com.dcloud.android.v4.view;
/*    */ 
/*    */ import android.graphics.Rect;
/*    */ import android.view.View;
/*    */ 
/*    */ class ViewCompatJellybeanMr2
/*    */ {
/*    */   public static Rect getClipBounds(View paramView)
/*    */   {
/* 28 */     return paramView.getClipBounds();
/*    */   }
/*    */ 
/*    */   public static void setClipBounds(View paramView, Rect paramRect) {
/* 32 */     paramView.setClipBounds(paramRect);
/*    */   }
/*    */ }

/* Location:           F:\xunlei\sdk\Android-SDK@1.9.9.29448_20170217\Android-SDK\SDK\libs\pdr.jar
 * Qualified Name:     com.dcloud.android.v4.view.ViewCompatJellybeanMr2
 * JD-Core Version:    0.6.2
 */